import React, { useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withDelay,
  withRepeat,
  withSequence,
  withSpring,
  Easing,
  FadeIn,
  FadeInDown,
  FadeInUp,
} from 'react-native-reanimated';
import { Ionicons, FontAwesome, MaterialIcons } from '@expo/vector-icons';
import { colors, spacing, borderRadius, shadows } from '../lib/theme';
import { quizQuestions } from '../lib/quizData';

const { width } = Dimensions.get('window');

interface ResultScreenProps {
  score: number;
  totalScore: number;
  onRestart: () => void;
  onHome: () => void;
}

export default function ResultScreen({
  score,
  totalScore,
  onRestart,
  onHome,
}: ResultScreenProps) {
  const percentage = Math.round((score / totalScore) * 100);
  const correctCount = score / 10;
  const totalQuestions = quizQuestions.length;

  const circleProgress = useSharedValue(0);
  const trophyScale = useSharedValue(0);
  const starRotation = useSharedValue(0);

  const isExcellent = percentage >= 80;
  const isGood = percentage >= 50;

  const getMessage = () => {
    if (percentage === 100) return 'ممتاز! نتيجة مثالية';
    if (percentage >= 80) return 'أحسنت! نتيجة رائعة';
    if (percentage >= 60) return 'جيد جداً! استمر';
    if (percentage >= 40) return 'لا بأس، حاول مرة أخرى';
    return 'لا تيأس، حاول مرة أخرى';
  };

  const getEmoji = () => {
    if (percentage === 100) return 'trophy';
    if (percentage >= 80) return 'star';
    if (percentage >= 60) return 'thumbs-up';
    if (percentage >= 40) return 'hand-peace-o';
    return 'refresh';
  };

  const getGradeColor = () => {
    if (percentage >= 80) return colors.correct;
    if (percentage >= 60) return colors.accent;
    if (percentage >= 40) return '#F39C12';
    return colors.incorrect;
  };

  useEffect(() => {
    circleProgress.value = withDelay(
      500,
      withTiming(percentage, { duration: 1500, easing: Easing.out(Easing.cubic) })
    );
    trophyScale.value = withDelay(
      300,
      withSpring(1, { damping: 6, stiffness: 100 })
    );
    if (isExcellent) {
      starRotation.value = withDelay(
        800,
        withRepeat(
          withSequence(
            withTiming(10, { duration: 300 }),
            withTiming(-10, { duration: 600 }),
            withTiming(0, { duration: 300 })
          ),
          3,
          false
        )
      );
    }
  }, []);

  const trophyStyle = useAnimatedStyle(() => ({
    transform: [{ scale: trophyScale.value }],
  }));

  const starStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${starRotation.value}deg` }],
  }));

  const circleStyle = useAnimatedStyle(() => {
    const circumference = 2 * Math.PI * 70;
    const strokeDashoffset =
      circumference - (circleProgress.value / 100) * circumference;
    return {
      // We'll use width to represent progress for the fill view
      width: `${circleProgress.value}%` as any,
    };
  });

  const renderStars = () => {
    const starCount = 5;
    const filledStars =
      percentage >= 100
        ? 5
        : percentage >= 80
        ? 4
        : percentage >= 60
        ? 3
        : percentage >= 40
        ? 2
        : percentage >= 20
        ? 1
        : 0;

    return (
      <View style={styles.starsContainer}>
        {Array.from({ length: starCount }).map((_, i) => (
          <Animated.View
            key={i}
            entering={FadeIn.delay(1000 + i * 200).duration(400)}
          >
            <FontAwesome
              name={i < filledStars ? 'star' : 'star-o'}
              size={28}
              color={i < filledStars ? colors.gold : colors.starEmpty}
            />
          </Animated.View>
        ))}
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        {/* Celebration decorations for high scores */}
        {isExcellent && (
          <>
            <Animated.View
              entering={FadeIn.delay(1500).duration(600)}
              style={[styles.confetti, { top: '8%', left: '10%' }]}
            >
              <FontAwesome name="star" size={16} color={colors.accent} />
            </Animated.View>
            <Animated.View
              entering={FadeIn.delay(1700).duration(600)}
              style={[styles.confetti, { top: '12%', right: '15%' }]}
            >
              <FontAwesome name="star" size={12} color={colors.primaryLight} />
            </Animated.View>
            <Animated.View
              entering={FadeIn.delay(1900).duration(600)}
              style={[styles.confetti, { top: '5%', right: '35%' }]}
            >
              <FontAwesome name="star" size={20} color={colors.gold} />
            </Animated.View>
          </>
        )}

        {/* Trophy / Icon */}
        <Animated.View style={[styles.trophyArea, trophyStyle]}>
          <Animated.View style={starStyle}>
            <View
              style={[
                styles.trophyCircle,
                { borderColor: getGradeColor() },
              ]}
            >
              <FontAwesome
                name={getEmoji() as any}
                size={52}
                color={getGradeColor()}
              />
            </View>
          </Animated.View>
        </Animated.View>

        {/* Stars */}
        {renderStars()}

        {/* Message */}
        <Animated.View entering={FadeInDown.delay(600).duration(600)}>
          <Text style={styles.messageText}>{getMessage()}</Text>
        </Animated.View>

        {/* Score display */}
        <Animated.View
          entering={FadeInDown.delay(800).duration(600)}
          style={styles.scoreCard}
        >
          <Text style={styles.scoreLabel}>النتيجة</Text>
          <View style={styles.scoreRow}>
            <Text style={[styles.scoreBig, { color: getGradeColor() }]}>
              {score}
            </Text>
            <Text style={styles.scoreDivider}>/</Text>
            <Text style={styles.scoreTotal}>{totalScore}</Text>
          </View>

          {/* Progress bar */}
          <View style={styles.barContainer}>
            <View style={styles.barBg}>
              <Animated.View
                style={[
                  styles.barFill,
                  circleStyle,
                  { backgroundColor: getGradeColor() },
                ]}
              />
            </View>
            <Text style={[styles.percentText, { color: getGradeColor() }]}>
              %{percentage}
            </Text>
          </View>
        </Animated.View>

        {/* Stats */}
        <Animated.View
          entering={FadeInDown.delay(1000).duration(600)}
          style={styles.statsRow}
        >
          <View style={styles.statCard}>
            <View
              style={[
                styles.statIcon,
                { backgroundColor: colors.correctBg },
              ]}
            >
              <Ionicons
                name="checkmark-circle"
                size={24}
                color={colors.correct}
              />
            </View>
            <Text style={styles.statValue}>{correctCount}</Text>
            <Text style={styles.statLabel}>صحيحة</Text>
          </View>
          <View style={styles.statCard}>
            <View
              style={[
                styles.statIcon,
                { backgroundColor: colors.incorrectBg },
              ]}
            >
              <Ionicons
                name="close-circle"
                size={24}
                color={colors.incorrect}
              />
            </View>
            <Text style={styles.statValue}>
              {totalQuestions - correctCount}
            </Text>
            <Text style={styles.statLabel}>خاطئة</Text>
          </View>
          <View style={styles.statCard}>
            <View
              style={[
                styles.statIcon,
                { backgroundColor: 'rgba(212, 168, 67, 0.15)' },
              ]}
            >
              <Ionicons name="help-circle" size={24} color={colors.accent} />
            </View>
            <Text style={styles.statValue}>{totalQuestions}</Text>
            <Text style={styles.statLabel}>المجموع</Text>
          </View>
        </Animated.View>

        {/* Buttons */}
        <Animated.View
          entering={FadeInUp.delay(1200).duration(600)}
          style={styles.buttonsContainer}
        >
          <TouchableOpacity
            style={styles.restartButton}
            onPress={onRestart}
            activeOpacity={0.8}
          >
            <Ionicons name="refresh" size={20} color={colors.textPrimary} />
            <Text style={styles.restartButtonText}>إعادة الاختبار</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.homeButton}
            onPress={onHome}
            activeOpacity={0.8}
          >
            <Ionicons name="home" size={20} color={colors.bgDark} />
            <Text style={styles.homeButtonText}>الرئيسية</Text>
          </TouchableOpacity>
        </Animated.View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgDark,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.lg,
  },
  confetti: {
    position: 'absolute',
    opacity: 0.6,
  },
  trophyArea: {
    marginBottom: spacing.md,
  },
  trophyCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: colors.bgCard,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 4,
    ...shadows.glow,
  },
  starsContainer: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  messageText: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.textPrimary,
    textAlign: 'center',
    marginBottom: spacing.lg,
    writingDirection: 'rtl',
  },
  scoreCard: {
    width: '100%',
    backgroundColor: colors.bgCard,
    borderRadius: borderRadius.xl,
    padding: spacing.xl,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: spacing.lg,
    ...shadows.card,
  },
  scoreLabel: {
    fontSize: 14,
    color: colors.textMuted,
    marginBottom: spacing.sm,
    writingDirection: 'rtl',
  },
  scoreRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginBottom: spacing.md,
  },
  scoreBig: {
    fontSize: 48,
    fontWeight: '800',
  },
  scoreDivider: {
    fontSize: 32,
    color: colors.textMuted,
    marginHorizontal: spacing.sm,
  },
  scoreTotal: {
    fontSize: 28,
    fontWeight: '600',
    color: colors.textMuted,
  },
  barContainer: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  barBg: {
    flex: 1,
    height: 10,
    backgroundColor: colors.bgCardLight,
    borderRadius: 5,
    overflow: 'hidden',
  },
  barFill: {
    height: '100%',
    borderRadius: 5,
  },
  percentText: {
    fontSize: 16,
    fontWeight: '700',
    width: 50,
    textAlign: 'center',
  },
  statsRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    width: '100%',
    marginBottom: spacing.xl,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.bgCard,
    borderRadius: borderRadius.lg,
    padding: spacing.md,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  statIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.xs,
  },
  statValue: {
    fontSize: 22,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  statLabel: {
    fontSize: 12,
    color: colors.textMuted,
    writingDirection: 'rtl',
  },
  buttonsContainer: {
    flexDirection: 'row',
    gap: spacing.md,
    width: '100%',
  },
  restartButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.bgCard,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.lg,
    borderWidth: 1,
    borderColor: colors.primary,
    gap: spacing.sm,
    ...shadows.button,
  },
  restartButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
    writingDirection: 'rtl',
  },
  homeButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.accent,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.lg,
    gap: spacing.sm,
    ...shadows.button,
  },
  homeButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.bgDark,
    writingDirection: 'rtl',
  },
});
