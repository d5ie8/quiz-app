import React, { useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withDelay,
  withRepeat,
  withSequence,
  Easing,
  FadeIn,
  FadeInDown,
} from 'react-native-reanimated';
import { Ionicons, MaterialIcons, FontAwesome } from '@expo/vector-icons';
import { colors, spacing, borderRadius, shadows } from '../lib/theme';
import { quizQuestions } from '../lib/quizData';

const { width } = Dimensions.get('window');

interface WelcomeScreenProps {
  onStartQuiz: () => void;
}

export default function WelcomeScreen({ onStartQuiz }: WelcomeScreenProps) {
  const pulseScale = useSharedValue(1);
  const starRotate = useSharedValue(0);
  const glowOpacity = useSharedValue(0.3);

  useEffect(() => {
    pulseScale.value = withRepeat(
      withSequence(
        withTiming(1.05, { duration: 1500, easing: Easing.inOut(Easing.ease) }),
        withTiming(1, { duration: 1500, easing: Easing.inOut(Easing.ease) })
      ),
      -1,
      true
    );
    starRotate.value = withRepeat(
      withTiming(360, { duration: 20000, easing: Easing.linear }),
      -1,
      false
    );
    glowOpacity.value = withRepeat(
      withSequence(
        withTiming(0.7, { duration: 2000 }),
        withTiming(0.3, { duration: 2000 })
      ),
      -1,
      true
    );
  }, []);

  const pulseStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulseScale.value }],
  }));

  const starStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${starRotate.value}deg` }],
  }));

  const glowStyle = useAnimatedStyle(() => ({
    opacity: glowOpacity.value,
  }));

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        {/* Decorative background elements */}
        <Animated.View style={[styles.bgDecor1, starStyle]}>
          <FontAwesome name="star" size={20} color={colors.accent} />
        </Animated.View>
        <Animated.View style={[styles.bgDecor2, starStyle]}>
          <FontAwesome name="star" size={14} color={colors.primaryLight} />
        </Animated.View>
        <Animated.View style={[styles.bgDecor3, starStyle]}>
          <FontAwesome name="star" size={18} color={colors.accentLight} />
        </Animated.View>

        {/* Logo / Icon area */}
        <Animated.View
          entering={FadeIn.delay(200).duration(800)}
          style={styles.logoArea}
        >
          <Animated.View style={[styles.glowCircle, glowStyle]} />
          <Animated.View style={[styles.logoCircle, pulseStyle]}>
            <MaterialIcons name="quiz" size={56} color={colors.accent} />
          </Animated.View>
        </Animated.View>

        {/* Title */}
        <Animated.View entering={FadeInDown.delay(500).duration(700)}>
          <Text style={styles.title}>مسابقة المعرفة</Text>
          <Text style={styles.subtitle}>اختبر معلوماتك العامة</Text>
        </Animated.View>

        {/* Info cards */}
        <Animated.View
          entering={FadeInDown.delay(800).duration(700)}
          style={styles.infoContainer}
        >
          <View style={styles.infoCard}>
            <View style={styles.infoIconWrap}>
              <Ionicons name="help-circle" size={24} color={colors.primaryLight} />
            </View>
            <Text style={styles.infoValue}>{quizQuestions.length}</Text>
            <Text style={styles.infoLabel}>أسئلة</Text>
          </View>
          <View style={styles.infoCard}>
            <View style={styles.infoIconWrap}>
              <Ionicons name="trophy" size={24} color={colors.accent} />
            </View>
            <Text style={styles.infoValue}>{quizQuestions.length * 10}</Text>
            <Text style={styles.infoLabel}>نقطة</Text>
          </View>
          <View style={styles.infoCard}>
            <View style={styles.infoIconWrap}>
              <Ionicons name="language" size={24} color={colors.correct} />
            </View>
            <Text style={styles.infoValue}>عربي</Text>
            <Text style={styles.infoLabel}>اللغة</Text>
          </View>
        </Animated.View>

        {/* Rules */}
        <Animated.View
          entering={FadeInDown.delay(1100).duration(700)}
          style={styles.rulesCard}
        >
          <Text style={styles.rulesTitle}>كيف تلعب؟</Text>
          <View style={styles.ruleRow}>
            <Text style={styles.ruleText}>اختر الإجابة الصحيحة لكل سؤال</Text>
            <View style={styles.ruleBullet}>
              <Text style={styles.ruleBulletText}>١</Text>
            </View>
          </View>
          <View style={styles.ruleRow}>
            <Text style={styles.ruleText}>احصل على ١٠ نقاط لكل إجابة صحيحة</Text>
            <View style={styles.ruleBullet}>
              <Text style={styles.ruleBulletText}>٢</Text>
            </View>
          </View>
          <View style={styles.ruleRow}>
            <Text style={styles.ruleText}>شاهد نتيجتك في نهاية الاختبار</Text>
            <View style={styles.ruleBullet}>
              <Text style={styles.ruleBulletText}>٣</Text>
            </View>
          </View>
        </Animated.View>

        {/* Start Button */}
        <Animated.View entering={FadeInDown.delay(1400).duration(700)}>
          <TouchableOpacity
            style={styles.startButton}
            onPress={onStartQuiz}
            activeOpacity={0.8}
          >
            <Ionicons
              name="play"
              size={22}
              color={colors.bgDark}
              style={{ marginLeft: spacing.sm }}
            />
            <Text style={styles.startButtonText}>ابدأ الاختبار</Text>
          </TouchableOpacity>
        </Animated.View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgDark,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.lg,
  },
  bgDecor1: {
    position: 'absolute',
    top: '12%',
    left: '15%',
    opacity: 0.3,
  },
  bgDecor2: {
    position: 'absolute',
    top: '20%',
    right: '10%',
    opacity: 0.2,
  },
  bgDecor3: {
    position: 'absolute',
    bottom: '18%',
    left: '20%',
    opacity: 0.25,
  },
  logoArea: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.lg,
  },
  glowCircle: {
    position: 'absolute',
    width: 140,
    height: 140,
    borderRadius: 70,
    backgroundColor: colors.primary,
  },
  logoCircle: {
    width: 110,
    height: 110,
    borderRadius: 55,
    backgroundColor: colors.bgCard,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    borderColor: colors.primary,
    ...shadows.glow,
  },
  title: {
    fontSize: 34,
    fontWeight: '800',
    color: colors.textPrimary,
    textAlign: 'center',
    marginBottom: spacing.xs,
    writingDirection: 'rtl',
  },
  subtitle: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: spacing.xl,
    writingDirection: 'rtl',
  },
  infoContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: spacing.md,
    marginBottom: spacing.lg,
    width: '100%',
  },
  infoCard: {
    flex: 1,
    backgroundColor: colors.bgCard,
    borderRadius: borderRadius.lg,
    padding: spacing.md,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
    ...shadows.card,
  },
  infoIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.bgCardLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.sm,
  },
  infoValue: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: 2,
  },
  infoLabel: {
    fontSize: 12,
    color: colors.textMuted,
    writingDirection: 'rtl',
  },
  rulesCard: {
    width: '100%',
    backgroundColor: colors.bgCard,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.xl,
    borderWidth: 1,
    borderColor: colors.border,
    ...shadows.card,
  },
  rulesTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.accent,
    textAlign: 'right',
    marginBottom: spacing.md,
    writingDirection: 'rtl',
  },
  ruleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    marginBottom: spacing.sm,
  },
  ruleText: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'right',
    flex: 1,
    marginRight: spacing.sm,
    writingDirection: 'rtl',
  },
  ruleBullet: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.primaryDark,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ruleBulletText: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.primaryLight,
  },
  startButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.accent,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xxl,
    borderRadius: borderRadius.round,
    ...shadows.button,
  },
  startButtonText: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.bgDark,
    writingDirection: 'rtl',
  },
});
