import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withDelay,
  withSequence,
  withSpring,
  Easing,
  FadeIn,
  FadeInDown,
  FadeOut,
  SlideInRight,
  runOnJS,
} from 'react-native-reanimated';
import { Ionicons, MaterialIcons, FontAwesome } from '@expo/vector-icons';
import { colors, spacing, borderRadius, shadows } from '../lib/theme';
import { quizQuestions, Question } from '../lib/quizData';

const { width } = Dimensions.get('window');

interface QuizScreenProps {
  onFinish: (score: number, total: number) => void;
}

const OPTION_LABELS = ['A', 'B', 'C', 'D'];

export default function QuizScreen({ onFinish }: QuizScreenProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [questionKey, setQuestionKey] = useState(0);

  const progressWidth = useSharedValue(0);
  const shakeX = useSharedValue(0);
  const scorePopScale = useSharedValue(0);

  const currentQuestion = quizQuestions[currentIndex];
  const totalQuestions = quizQuestions.length;

  useEffect(() => {
    progressWidth.value = withTiming(
      ((currentIndex + 1) / totalQuestions) * 100,
      { duration: 600, easing: Easing.out(Easing.cubic) }
    );
  }, [currentIndex]);

  const progressStyle = useAnimatedStyle(() => ({
    width: `${progressWidth.value}%` as any,
  }));

  const shakeStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: shakeX.value }],
  }));

  const scorePopStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scorePopScale.value }],
    opacity: scorePopScale.value,
  }));

  const handleAnswer = useCallback(
    (answer: string) => {
      if (showFeedback || isTransitioning) return;

      setSelectedAnswer(answer);
      setShowFeedback(true);

      const isCorrect = answer === currentQuestion.correctAnswer;

      if (isCorrect) {
        setScore((prev) => prev + 10);
        scorePopScale.value = withSequence(
          withSpring(1.3, { damping: 4 }),
          withDelay(600, withTiming(0, { duration: 300 }))
        );
      } else {
        shakeX.value = withSequence(
          withTiming(-10, { duration: 50 }),
          withTiming(10, { duration: 100 }),
          withTiming(-10, { duration: 100 }),
          withTiming(10, { duration: 100 }),
          withTiming(0, { duration: 50 })
        );
      }

      // Move to next question or finish
      setTimeout(() => {
        setIsTransitioning(true);
        setTimeout(() => {
          if (currentIndex < totalQuestions - 1) {
            setCurrentIndex((prev) => prev + 1);
            setSelectedAnswer(null);
            setShowFeedback(false);
            setIsTransitioning(false);
            setQuestionKey((prev) => prev + 1);
          } else {
            const finalScore = isCorrect ? score + 10 : score;
            onFinish(finalScore, totalQuestions * 10);
          }
        }, 300);
      }, 1200);
    },
    [currentIndex, currentQuestion, score, showFeedback, isTransitioning]
  );

  const getOptionStyle = (option: string) => {
    if (!showFeedback) return {};
    if (option === currentQuestion.correctAnswer) {
      return {
        backgroundColor: colors.correctBg,
        borderColor: colors.correct,
      };
    }
    if (option === selectedAnswer && option !== currentQuestion.correctAnswer) {
      return {
        backgroundColor: colors.incorrectBg,
        borderColor: colors.incorrect,
      };
    }
    return { opacity: 0.4 };
  };

  const getOptionIcon = (option: string) => {
    if (!showFeedback) return null;
    if (option === currentQuestion.correctAnswer) {
      return <Ionicons name="checkmark-circle" size={24} color={colors.correct} />;
    }
    if (option === selectedAnswer && option !== currentQuestion.correctAnswer) {
      return <Ionicons name="close-circle" size={24} color={colors.incorrect} />;
    }
    return null;
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.scoreContainer}>
          <Ionicons name="star" size={18} color={colors.accent} />
          <Text style={styles.scoreText}>{score}</Text>
        </View>
        <View style={styles.questionCounter}>
          <Text style={styles.counterText}>
            {currentIndex + 1} / {totalQuestions}
          </Text>
        </View>
      </View>

      {/* Progress bar */}
      <View style={styles.progressContainer}>
        <View style={styles.progressBg}>
          <Animated.View style={[styles.progressFill, progressStyle]} />
        </View>
      </View>

      {/* Score popup */}
      <Animated.View style={[styles.scorePop, scorePopStyle]}>
        <Text style={styles.scorePopText}>+١٠</Text>
      </Animated.View>

      {/* Question Card */}
      <Animated.View
        key={`q-${questionKey}`}
        entering={FadeIn.duration(400)}
        style={styles.questionArea}
      >
        <Animated.View style={[styles.questionCard, shakeStyle]}>
          <View style={styles.questionNumberBadge}>
            <Text style={styles.questionNumberText}>
              سؤال {currentIndex + 1}
            </Text>
          </View>
          <Text style={styles.questionText}>{currentQuestion.question}</Text>
        </Animated.View>

        {/* Options */}
        <View style={styles.optionsContainer}>
          {currentQuestion.options.map((option, index) => (
            <Animated.View
              key={`${questionKey}-${index}`}
              entering={FadeInDown.delay(100 + index * 100).duration(400)}
            >
              <TouchableOpacity
                style={[
                  styles.optionButton,
                  getOptionStyle(option),
                  selectedAnswer === option && showFeedback
                    ? shadows.button
                    : {},
                ]}
                onPress={() => handleAnswer(option)}
                activeOpacity={0.7}
                disabled={showFeedback}
              >
                <View style={styles.optionLeft}>
                  {getOptionIcon(option)}
                </View>
                <Text
                  style={[
                    styles.optionText,
                    showFeedback &&
                      option === currentQuestion.correctAnswer && {
                        color: colors.correct,
                        fontWeight: '700',
                      },
                    showFeedback &&
                      option === selectedAnswer &&
                      option !== currentQuestion.correctAnswer && {
                        color: colors.incorrect,
                      },
                  ]}
                >
                  {option}
                </Text>
                <View style={styles.optionLabel}>
                  <Text style={styles.optionLabelText}>
                    {OPTION_LABELS[index]}
                  </Text>
                </View>
              </TouchableOpacity>
            </Animated.View>
          ))}
        </View>
      </Animated.View>

      {/* Bottom dots indicator */}
      <View style={styles.dotsContainer}>
        {quizQuestions.map((_, index) => (
          <View
            key={index}
            style={[
              styles.dot,
              index === currentIndex && styles.dotActive,
              index < currentIndex && styles.dotCompleted,
            ]}
          />
        ))}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgDark,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
    paddingBottom: spacing.sm,
  },
  scoreContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgCard,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.round,
    gap: spacing.xs,
    borderWidth: 1,
    borderColor: colors.border,
  },
  scoreText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.accent,
  },
  questionCounter: {
    backgroundColor: colors.bgCard,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.round,
    borderWidth: 1,
    borderColor: colors.border,
  },
  counterText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  progressContainer: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
  },
  progressBg: {
    height: 6,
    backgroundColor: colors.bgCard,
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.primary,
    borderRadius: 3,
  },
  scorePop: {
    position: 'absolute',
    top: '15%',
    alignSelf: 'center',
    zIndex: 100,
    backgroundColor: colors.correct,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.round,
  },
  scorePopText: {
    fontSize: 24,
    fontWeight: '800',
    color: '#fff',
  },
  questionArea: {
    flex: 1,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
  },
  questionCard: {
    backgroundColor: colors.bgCard,
    borderRadius: borderRadius.xl,
    padding: spacing.xl,
    marginBottom: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
    ...shadows.card,
    alignItems: 'center',
  },
  questionNumberBadge: {
    backgroundColor: colors.primaryDark,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.round,
    marginBottom: spacing.md,
  },
  questionNumberText: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.primaryLight,
    writingDirection: 'rtl',
  },
  questionText: {
    fontSize: 22,
    fontWeight: '700',
    color: colors.textPrimary,
    textAlign: 'center',
    lineHeight: 34,
    writingDirection: 'rtl',
  },
  optionsContainer: {
    gap: spacing.sm,
  },
  optionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgCard,
    borderRadius: borderRadius.lg,
    padding: spacing.md,
    borderWidth: 1.5,
    borderColor: colors.border,
  },
  optionLeft: {
    width: 28,
    alignItems: 'center',
  },
  optionText: {
    flex: 1,
    fontSize: 18,
    color: colors.textPrimary,
    textAlign: 'right',
    writingDirection: 'rtl',
    fontWeight: '500',
  },
  optionLabel: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.bgCardLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: spacing.sm,
  },
  optionLabelText: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textMuted,
  },
  dotsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: spacing.lg,
    gap: spacing.sm,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.bgCardLight,
  },
  dotActive: {
    width: 24,
    backgroundColor: colors.primary,
  },
  dotCompleted: {
    backgroundColor: colors.correct,
  },
});
