export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: string;
}

export const quizQuestions: Question[] = [
  {
    id: 1,
    question: "ما هي عاصمة اليمن؟",
    options: ["صنعاء", "عدن", "المكلا", "تعز"],
    correctAnswer: "صنعاء",
  },
  {
    id: 2,
    question: "كم عدد أضلاع المربع؟",
    options: ["3", "4", "5", "6"],
    correctAnswer: "4",
  },
  {
    id: 3,
    question: "ما هو أكبر كوكب في المجموعة الشمسية؟",
    options: ["الأرض", "المريخ", "المشتري", "زحل"],
    correctAnswer: "المشتري",
  },
  {
    id: 4,
    question: "كم عدد أيام السنة الميلادية؟",
    options: ["360", "365", "370", "355"],
    correctAnswer: "365",
  },
  {
    id: 5,
    question: "ما هي أطول نهر في العالم؟",
    options: ["دجلة", "الفرات", "النيل", "الأمازون"],
    correctAnswer: "النيل",
  },
  {
    id: 6,
    question: "ما هو العنصر الكيميائي الذي رمزه O؟",
    options: ["الذهب", "الأكسجين", "الحديد", "الفضة"],
    correctAnswer: "الأكسجين",
  },
  {
    id: 7,
    question: "كم عدد أركان الإسلام؟",
    options: ["3", "4", "5", "6"],
    correctAnswer: "5",
  },
  {
    id: 8,
    question: "ما هي أصغر دولة في العالم؟",
    options: ["موناكو", "الفاتيكان", "سان مارينو", "مالطا"],
    correctAnswer: "الفاتيكان",
  },
];
