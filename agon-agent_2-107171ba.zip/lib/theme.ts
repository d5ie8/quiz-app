export const colors = {
  // Main palette - deep teal & gold inspired by Arabic/Islamic art
  primary: '#0D7377',
  primaryDark: '#095B5E',
  primaryLight: '#14A3A8',
  accent: '#D4A843',
  accentLight: '#F0D78C',
  
  // Backgrounds
  bgDark: '#0A1628',
  bgCard: '#122240',
  bgCardLight: '#1A2E52',
  
  // Feedback
  correct: '#2ECC71',
  correctBg: 'rgba(46, 204, 113, 0.15)',
  incorrect: '#E74C3C',
  incorrectBg: 'rgba(231, 76, 60, 0.15)',
  
  // Text
  textPrimary: '#FFFFFF',
  textSecondary: '#A0B4D0',
  textMuted: '#6B7FA0',
  
  // Misc
  border: '#1E3A5F',
  shadow: '#000000',
  overlay: 'rgba(10, 22, 40, 0.85)',
  gold: '#FFD700',
  starEmpty: '#2A3F60',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const borderRadius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  round: 999,
};

export const shadows = {
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  button: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 4,
  },
  glow: {
    shadowColor: '#0D7377',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 6,
  },
};
