import React, { useState, useCallback } from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, View, Platform, I18nManager } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useFonts } from 'expo-font';
import { Ionicons, FontAwesome, MaterialIcons } from '@expo/vector-icons';
import WelcomeScreen from './screens/WelcomeScreen';
import QuizScreen from './screens/QuizScreen';
import ResultScreen from './screens/ResultScreen';

type Screen = 'welcome' | 'quiz' | 'result';

export default function App() {
  const [fontsLoaded] = useFonts({
    ...Ionicons.font,
    ...FontAwesome.font,
    ...MaterialIcons.font,
  });

  const [currentScreen, setCurrentScreen] = useState<Screen>('welcome');
  const [finalScore, setFinalScore] = useState(0);
  const [totalScore, setTotalScore] = useState(0);

  const handleStartQuiz = useCallback(() => {
    setCurrentScreen('quiz');
  }, []);

  const handleFinishQuiz = useCallback((score: number, total: number) => {
    setFinalScore(score);
    setTotalScore(total);
    setCurrentScreen('result');
  }, []);

  const handleRestart = useCallback(() => {
    setFinalScore(0);
    setTotalScore(0);
    setCurrentScreen('quiz');
  }, []);

  const handleHome = useCallback(() => {
    setFinalScore(0);
    setTotalScore(0);
    setCurrentScreen('welcome');
  }, []);

  if (!fontsLoaded) {
    return (
      <View style={styles.loading}>
        <StatusBar style="light" />
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <View style={styles.container}>
        <StatusBar style="light" />
        {currentScreen === 'welcome' && (
          <WelcomeScreen onStartQuiz={handleStartQuiz} />
        )}
        {currentScreen === 'quiz' && (
          <QuizScreen
            key={`quiz-${Date.now()}`}
            onFinish={handleFinishQuiz}
          />
        )}
        {currentScreen === 'result' && (
          <ResultScreen
            score={finalScore}
            totalScore={totalScore}
            onRestart={handleRestart}
            onHome={handleHome}
          />
        )}
      </View>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1628',
  },
  loading: {
    flex: 1,
    backgroundColor: '#0A1628',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
